/**
 * 
 */
/**
 * 
 */
module project1casting {
}