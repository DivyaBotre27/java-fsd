package demo2;

public class innerClassAssisted1 {

	private String msg="Inner Classes";
	
	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	  }  
	  
	  Inner l=new Inner();  
	  l.msg();  
	 }  
	
	 
	public static void main(String[] args) {
		innerClassAssisted1  ob=new innerClassAssisted1 ();  
		ob.display();  
		}
	}

